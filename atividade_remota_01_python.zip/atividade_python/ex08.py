################################################################
# Descrição: Calcula a soma dos cem primeiros números naturais, de 1 a 100.#
# Parâmetros de entrada: Não há entrada de dados.                   #
# Valores de saída: A soma de 1 + 2 + ... + 100.                   #
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

soma = 0

for numero in range(1, 101):
    soma += numero

print("A soma dos cem primeiros números naturais é:", soma)
