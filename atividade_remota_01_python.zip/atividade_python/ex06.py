################################################################
# Descrição: Apresenta os quadrados dos números inteiros de 15 a 200.#
# Parâmetros de entrada: Não há entrada de dados.                   #
# Valores de saída: O quadrado de cada inteiro no intervalo de 15 a 200, inclusive.#
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

for numero in range(15, 201):
    print(f"{numero}² = {numero ** 2}")
