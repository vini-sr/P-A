################################################################
# Descrição: Solicita dois números e imprime o maior deles.      #
# Parâmetros de entrada: Dois números informados pelo usuário.      #
# Valores de saída: O maior número; se forem iguais, informa que são iguais.#
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

if n1 > n2:
    print("Maior número:", n1)
elif n2 > n1:
    print("Maior número:", n2)
else:
    print("Os números são iguais.")
