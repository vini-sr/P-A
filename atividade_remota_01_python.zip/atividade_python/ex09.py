################################################################
# Descrição: Calcula a soma dos números pares existentes entre 1 e 500.#
# Parâmetros de entrada: Não há entrada de dados.                   #
# Valores de saída: O somatório dos números pares de 1 até 500.    #
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

soma = 0

for numero in range(1, 501):
    if numero % 2 == 0:
        soma += numero

print("A soma dos números pares de 1 até 500 é:", soma)
