################################################################
# Descrição: Solicita um valor e informa se é positivo ou negativo.#
# Parâmetros de entrada: Um número informado pelo usuário.          #
# Valores de saída: A classificação do número como positivo, negativo ou zero.#
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

valor = float(input("Digite um valor: "))

if valor > 0:
    print("Positivo")
elif valor < 0:
    print("Negativo")
else:
    print("O valor é zero.")
