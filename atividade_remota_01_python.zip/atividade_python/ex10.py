################################################################
# Descrição: Apresenta os números inteiros ímpares de 0 a 20.    #
# Parâmetros de entrada: Não há entrada de dados.                   #
# Valores de saída: Os números ímpares no intervalo de 0 a 20, inclusive.#
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

for numero in range(0, 21):
    if numero % 2 != 0:
        print(numero)
