################################################################
# Descrição: Verifica se a letra informada corresponde a F ou M. #
# Parâmetros de entrada: Uma letra informada pelo usuário.          #
# Valores de saída: F - Feminino, M - Masculino ou Sexo Inválido.  #
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

letra = input("Digite F ou M: ").strip().upper()

if letra == "F":
    print("F - Feminino")
elif letra == "M":
    print("M - Masculino")
else:
    print("Sexo Inválido")
