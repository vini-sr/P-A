################################################################
# Descrição: Calcula a média de duas notas e informa a situação do aluno.#
# Parâmetros de entrada: Duas notas parciais.                       #
# Valores de saída: Aprovado, Reprovado ou Aprovado com Distinção. #
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))
media = (nota1 + nota2) / 2

print(f"Média: {media:.2f}")

if media == 10:
    print("Aprovado com Distinção")
elif media >= 7:
    print("Aprovado")
else:
    print("Reprovado")
