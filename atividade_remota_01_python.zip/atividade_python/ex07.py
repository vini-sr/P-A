################################################################
# Descrição: Mostra a tabuada de um número informado pelo usuário.#
# Parâmetros de entrada: Um número informado pelo usuário.          #
# Valores de saída: A tabuada do número de 1 a 10.                 #
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

numero = float(input("Digite um número para ver a tabuada: "))

for multiplicador in range(1, 11):
    resultado = numero * multiplicador
    print(f"{numero:g} x {multiplicador} = {resultado:g}")
