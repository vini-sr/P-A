################################################################
# Descrição: Identifica o turno de estudo e exibe a saudação correspondente.#
# Parâmetros de entrada: M para Matutino, V para Vespertino ou N para Noturno.#
# Valores de saída: Bom Dia!, Boa Tarde!, Boa Noite! ou Valor Inválido!.#
# Autor:                 [PREENCHER COM SEU NOME COMPLETO]       #
################################################################

turno = input("Informe o turno (M - Matutino, V - Vespertino, N - Noturno): ").strip().upper()

if turno == "M":
    print("Bom Dia!")
elif turno == "V":
    print("Boa Tarde!")
elif turno == "N":
    print("Boa Noite!")
else:
    print("Valor Inválido!")
