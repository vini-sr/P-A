# Atividade Remota 01 — Python

Exercícios desenvolvidos em arquivos Python separados, conforme a lista da atividade.

## Arquivos
- `ex01.py` até `ex10.py`: soluções dos dez exercícios.

## Antes de entregar
1. Abra cada arquivo e substitua `[PREENCHER COM SEU NOME COMPLETO]` pelo seu nome completo.
2. Execute os arquivos com Python 3 para conferir os resultados.
3. Crie um repositório **público** no GitHub (por exemplo, `atividade-remota-01`).
4. No terminal, dentro desta pasta, execute os comandos abaixo. Faça um commit por exercício:

```bash
git init
git branch -M main
git add ex01.py
git commit -m "feat: conclui o exercício 01"
git add ex02.py
git commit -m "feat: conclui o exercício 02"
git add ex03.py
git commit -m "feat: conclui o exercício 03"
git add ex04.py
git commit -m "feat: conclui o exercício 04"
git add ex05.py
git commit -m "feat: conclui o exercício 05"
git add ex06.py
git commit -m "feat: conclui o exercício 06"
git add ex07.py
git commit -m "feat: conclui o exercício 07"
git add ex08.py
git commit -m "feat: conclui o exercício 08"
git add ex09.py
git commit -m "feat: conclui o exercício 09"
git add ex10.py
git commit -m "feat: conclui o exercício 10"
```

5. Conecte o repositório remoto (troque a URL pela URL do repositório que você criou) e envie:

```bash
git remote add origin https://github.com/vini-sr/atividade-remota-01.git
git push -u origin main
```

6. Copie o link do repositório público e cole na atividade do MS Teams.

Perfil GitHub informado: https://github.com/vini-sr
